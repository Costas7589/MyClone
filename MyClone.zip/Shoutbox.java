  package virtualworld;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Shoutbox { 
   
public static void shoutOutCannedMessage(List<String> list) {
    Scanner Costas = new Scanner(System.in); 

   
       System.out.println("Please choose from options below: ");
       int size = list.size();

       for(int i=0; i<size; i++)
       {
           System.out.println(list.get(i));
       

       int userNumber;
       System.out.println("Please enter number: ");
       userNumber = Costas.nextInt();
       System.out.println(list.get(userNumber));
    
 String[]message = new String [5];


        //Add elements to the array 

        message[0]= "Hello World";
        message[1]= "I'm at the beach";
        message[2] = "I'm at the Sox game";
        message[3] = "I'm out for a run";
        message[4] = "I'm cooking in the kitchen";
        
String AC[] = {"Hello World"+ "I'm at the beach"+ "I'm at the Sox game" + "I'm out for a run" +
"I'm cooking in the kitchen"};
       
{
System.out.println("Would you like a canned or random message? 1= Canned, 2= Random");
int CR = Costas.nextInt(); 

System.out.println("Nice choice!Please see messages below:");
System.out.println(Arrays.toString(AC));

if (CR != 1)
{
    boolean Random = false;
    System.out.print(Random);

//method to get return value        

System.out.print("Select Message: ");
    i = 0;

AC[i] = Costas.nextLine();

if(i <= 0 || i > 10) {
   
}
{
    if(i >= 0 || i < 10)
        System.out.println(Arrays.toString(AC));
    
    
    //Ask for users message
    for(int index = 0; index < message.length; index++)
    {
        System.out.printf("Enter your messages %d:  ", (index + 1));
        message[index] = Costas.nextLine();
    }
    
    //Print out the users message
    for (int index = 0; index < message.length; index++)
    {
        System.out.printf("message #%d = %s./n", (index +1), message[index]);
    }}}}}}

  
public static void ShoutOutRandomMessage() {
     
 
//store array strings1

String[] Subject={"Tom Brady", "Greece", "iPhone"};
String[] Verb={"runs", "charges", "loves"};
String[] Adjective={"harry", "fancy", "handsome"};
String[] Object={"restaurants", "cars", "belts"};
String[] Adverb={"eternally", "firmly", "truthfully"};

Random random = new Random();


//randomly selects index from array

int s = random.nextInt(Subject.length);
int v = random.nextInt(Verb.length);
int a = random.nextInt(Adjective.length);
int o = random.nextInt(Object.length);
int adv = random.nextInt(Adverb.length);

// print out random message

System.out.println("Random String selected: " + Subject[s]);
System.out.println("Random String selected: " + Verb[v]); 
System.out.println("Random String selected: " + Adjective[a]);
System.out.println("Random String selected: " + Object[o]);
System.out.println("Random String selected: " + Adverb[adv]);

//Display entire contents of the Array and ArrayList



}}
    