package virtualworld;

import java.util.Scanner;

/**
 *
 * @author MonikaTHill
 */

//Additional object
public class PetObject {
    
 public static void main (String[] args) {
     
     
Scanner Costas = new Scanner(System.in);
 
 
 {
 System.out.println("Please enter the pet type: ");
 String petType = Costas.next();
        
 System.out.println("Please enter your pet's color");
 String petColor = Costas.next();
        
System.out.println("Please enter your pet's name: ");
String petName = Costas.next();


 System.out.println("He is a " + petColor + petType + "named" + petName);
 String Sparky= Costas.next();       
 }}

 
    //declaring instance variables
    private String petType;
    private String petName;
    private String petColor;
   
   //Constructor that initializes private variables
    
    private PetObject(String petType, String petColor, String petName) {  
    
    }
    
    private String getpetType() {
    return petType;
 
    }
         

    //Accessor for pet type
    private void setpetType(String petType) {
    this.petType = petType;

    }
    private String getpetColor() {
        return petColor;
    }

    private void setpetColor(String petColor) {
        this.petColor = petColor;
    }

    private String getpetName() {
        return petName;
    }

    private void setpetName(String petName) {
        this.petName = petName;
    }
    

 
AddClass Sparky;

      {
 /* Set Instance Variables */
 Sparky.setpetType("Dog");            
 Sparky.setpetColor("Brown");          
 Sparky.setpetName("Sparky");
     
        
 /* Display Information */
        System.out.println("This pet is a: " + 
                Sparky.getpetType());
                Sparky.getpetColor();
                Sparky.getpetName();

    
      
      }}