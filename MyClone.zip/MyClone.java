/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author costa
 */
 package virtualworld;
	
	//below is object/class MyClone for Virtual World
import java.util.Scanner;


    public class MyClone {
    public static void main (String[] args) {
    
 Scanner Costas = new Scanner(System.in);
 
 {
 System.out.println("Please enter your first name: ");
 String firstName = Costas.next();
        
 System.out.println("Please enter your last name:");
 String lastName = Costas.next();
        
System.out.println("Please enter your age: ");
String Age = Costas.next();


 System.out.println("Hello" + firstName + lastName + "You're" + Age + "years old and welcome to Virtual World!");
 String Introduction= Costas.next();
 
 
 }}
   //declaring instance variables
    public String firstName;
    public String lastName;
    public String Age;
   
   
       //Constructor that initializes private variables

public MyClone(String firstName, String lastName, String Age) {
       
        this.firstName = firstName;
        this.lastName = lastName;
        this.Age = Age;
    }
	 //Accessor for first name

    MyClone() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    public String getFirstName() {
        return firstName;
    }
        //Mutator for first name
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
         //Accessor for last name
    
    public String getLastName() {
        return lastName;
    }
    
       //Mutator for last name

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
         //Accessor for age
    
    public String getAge() {
        return Age;
    }
        //Mutator for age

    public void setAge(String Age) {
    this.Age = Age;                                                             
    
 
   
    
     /* Create Object */
 
MyClone Alex = new MyClone();
        
         /* Set Clone Instance Variables */
        Alex.setFirstName("Alex");            // Sets first name
        Alex.setLastName("Costas");           // Sets last name
        Alex.setAge("27");                       // Sets age
     
        
        /* Display Clone Information */
        System.out.println("This clone's name is: " + 
                Alex.getFirstName() + " " + 
                Alex.getLastName());
        
        System.out.println("He is " + 
                Alex.getAge() + "years old " + ".");
       
        
 }}



    /*  ---------------------------------------------------------------------------
    */
                
        